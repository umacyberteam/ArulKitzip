import { API_ORIGIN, DOCS_ORIGIN } from "@/lib/api";

const endpoints = [
  "GET /api/downloader/proxy",
  "GET /api/anime/search",
  "GET|POST /api/view-source",
];

export default function ApiHome() {
  const data = {
    name: "ArulKit API",
    version: "1.0.0",
    status: "online",
    baseUrl: API_ORIGIN,
    docs: DOCS_ORIGIN,
    endpoints,
  };

  return (
    <main className="shell" style={{ padding: "48px 0" }}>
      <h1 style={{ fontSize: "32px", fontWeight: 700 }}>ArulKit API</h1>
      <p style={{ marginTop: "8px", color: "var(--muted)" }}>
        REST API for developer integrations.
      </p>
      <pre
        style={{
          marginTop: "24px",
          padding: "20px",
          border: "1px solid var(--border)",
          borderRadius: "12px",
          background: "var(--surface)",
        }}
      >
        {JSON.stringify(data, null, 2)}
      </pre>
    </main>
  );
}
