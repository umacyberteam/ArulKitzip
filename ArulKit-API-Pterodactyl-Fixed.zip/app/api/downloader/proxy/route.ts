import { NextRequest, NextResponse } from "next/server";
import { SiputzxProvider } from "@/lib/downloader/providers/siputzx";
import { TikwmProvider } from "@/lib/downloader/providers/tikwm";
import { DownloaderError } from "@/lib/downloader/types";
import { apiJson, apiOptions, corsHeaders } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const TIKTOK_PAGE_HOSTS = ["tiktok.com", "vt.tiktok.com", "vm.tiktok.com"];
const TIKTOK_MEDIA_HOSTS = [
  "tiktokcdn.com",
  "tiktokcdn-us.com",
  "ibytedtos.com",
  "muscdn.com",
];
const INSTAGRAM_MEDIA_HOSTS = [
  "media.sssinstagram.com",
  "cdninstagram.com",
  "fbcdn.net",
];

function isHostAllowed(hostname: string, hosts: string[]) {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  return hosts.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
}

function safeFilename(value: string | null, fallback = "media") {
  const cleaned = (value || fallback).replace(/[\\/\0<>:"|?*\r\n]+/g, "_").trim();
  return cleaned.slice(0, 120) || fallback;
}

function formatError(err: unknown) {
  if (err instanceof DownloaderError) return { error: err.message, code: err.code };
  return { error: err instanceof Error ? err.message : "Gagal mengambil media." };
}

export async function OPTIONS() {
  return apiOptions();
}

export async function GET(req: NextRequest) {
  const source = req.nextUrl.searchParams.get("url")?.trim();
  const platform = req.nextUrl.searchParams.get("platform")?.trim().toLowerCase();
  const format = req.nextUrl.searchParams.get("format")?.trim();
  const filename = safeFilename(req.nextUrl.searchParams.get("filename"), "media.mp4");

  if (!source) return apiJson({ error: "Parameter 'url' wajib diisi." }, { status: 400 });

  let parsed: URL;
  try {
    parsed = new URL(source);
  } catch {
    return apiJson({ error: "URL media tidak valid." }, { status: 400 });
  }

  // Convenience mode for developers: pass the original TikTok URL and the
  // API resolves it through the same TikWM provider used by ArulKit.
  if (
    (platform === "tiktok" || (!platform && isHostAllowed(parsed.hostname, TIKTOK_PAGE_HOSTS))) &&
    isHostAllowed(parsed.hostname, TIKTOK_PAGE_HOSTS)
  ) {
    try {
      const result = await new TikwmProvider().resolve(source, "tiktok");
      const selected = result.formats.find((item) => item.id === (format || "hd")) || result.formats[0];
      if (!selected) return apiJson({ error: "Format TikTok tidak tersedia." }, { status: 404 });

      // The provider returns an internal proxy URL. Resolve its underlying URL
      // here so the public API can stream the file directly.
      const internal = new URL(selected.url, req.nextUrl.origin);
      const upstreamUrl = internal.searchParams.get("url");
      if (!upstreamUrl) return apiJson({ error: "URL media hasil resolve tidak valid." }, { status: 502 });
      return streamMedia(upstreamUrl, filename || `tiktok-${selected.id}.mp4`, "Media TikTok", TIKTOK_MEDIA_HOSTS);
    } catch (err) {
      return apiJson(formatError(err), { status: err instanceof DownloaderError && err.code === "not_found" ? 404 : 502 });
    }
  }

  if (platform === "instagram") {
    try {
      const result = await new SiputzxProvider().resolve(source, "instagram");
      const selected = format
        ? result.formats.find((item) => item.id === format)
        : result.formats[0];
      if (!selected) return apiJson({ error: "Format Instagram tidak tersedia." }, { status: 404 });

      const internal = new URL(selected.url, req.nextUrl.origin);
      const upstreamUrl = internal.searchParams.get("url");
      if (!upstreamUrl) return apiJson({ error: "URL media hasil resolve tidak valid." }, { status: 502 });
      return streamMedia(upstreamUrl, filename || `instagram-${selected.ext}`, "Media Instagram", INSTAGRAM_MEDIA_HOSTS);
    } catch (err) {
      return apiJson(formatError(err), { status: err instanceof DownloaderError && err.code === "not_found" ? 404 : 502 });
    }
  }

  if (parsed.protocol !== "https:" || !isHostAllowed(parsed.hostname, TIKTOK_MEDIA_HOSTS)) {
    return apiJson(
      {
        error: "Sumber media tidak diizinkan.",
        hint: "Gunakan URL TikTok publik atau URL media TikTok yang dihasilkan provider.",
      },
      { status: 403 }
    );
  }

  return streamMedia(parsed.toString(), filename, "Media TikTok", TIKTOK_MEDIA_HOSTS);
}

async function streamMedia(source: string, filename: string, label: string, allowedHosts: string[]) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 50_000);

  try {
    const upstream = await fetch(source, {
      headers: {
        Accept: "video/mp4,audio/mpeg,image/*,video/*,audio/*,*/*;q=0.8",
        "User-Agent": "Mozilla/5.0 (compatible; ArulKit API/1.0)",
      },
      signal: controller.signal,
      cache: "no-store",
      redirect: "follow",
    });

    if (!upstream.ok || !upstream.body) {
      return apiJson({ error: `Gagal mengambil ${label} (HTTP ${upstream.status}).` }, { status: 502 });
    }

    const finalUrl = new URL(upstream.url);
    if (finalUrl.protocol !== "https:") {
      return apiJson({ error: "Redirect media tidak diizinkan." }, { status: 502 });
    }
    if (!isHostAllowed(finalUrl.hostname, allowedHosts)) {
      return apiJson({ error: "Redirect media tidak diizinkan." }, { status: 502 });
    }

    const headers = corsHeaders();
    headers.set("Content-Type", upstream.headers.get("content-type") || "application/octet-stream");
    const length = upstream.headers.get("content-length");
    if (length) headers.set("Content-Length", length);
    headers.set("Content-Disposition", `attachment; filename="${filename}"`);
    headers.set("Cache-Control", "no-store");
    headers.set("X-Content-Type-Options", "nosniff");
    return new NextResponse(upstream.body, { status: 200, headers });
  } catch (err) {
    if ((err as Error).name === "AbortError") return apiJson({ error: "Download timeout." }, { status: 504 });
    return apiJson({ error: `Gagal mengambil ${label}.` }, { status: 502 });
  } finally {
    clearTimeout(timer);
  }
}
