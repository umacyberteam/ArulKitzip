import {
  DownloaderProvider,
  DownloaderError,
  DownloadResult,
  Platform,
} from "../types";

function toProxyUrl(sourceUrl: string, filename: string): string {
  const params = new URLSearchParams({
    url: sourceUrl,
    filename,
  });
  return `/api/downloader/proxy?${params.toString()}`;
}

export class TikwmProvider implements DownloaderProvider {
  name = "tikwm";
  supports: Platform[] = ["tiktok"];

  isConfigured(): boolean {
    return true;
  }

  async resolve(url: string, platform: Platform): Promise<DownloadResult> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12_000);

    const endpoint = new URL("https://www.tikwm.com/api/");
    endpoint.searchParams.set("url", url);
    endpoint.searchParams.set("hd", "1");

    let res: Response;
    try {
      res = await fetch(endpoint.toString(), {
        method: "GET",
        headers: {
          Accept: "application/json",
          "User-Agent": "ArulKit/1.0 (+https://arulkit.my.id)",
        },
        signal: controller.signal,
        cache: "no-store",
      });
    } catch (err) {
      if ((err as Error).name === "AbortError") {
        throw new DownloaderError("Provider TikTok timeout.", "timeout");
      }
      throw new DownloaderError(
        "Tidak bisa menghubungi provider TikTok saat ini.",
        "upstream_error"
      );
    } finally {
      clearTimeout(timeout);
    }

    if (!res.ok) {
      throw new DownloaderError(
        `Provider TikTok mengembalikan HTTP ${res.status}.`,
        "upstream_error"
      );
    }

    let data: any;
    try {
      data = await res.json();
    } catch {
      throw new DownloaderError(
        "Provider TikTok mengembalikan respons yang tidak valid.",
        "upstream_error"
      );
    }

    if (data.code !== 0 || !data.data) {
      throw new DownloaderError(
        data.msg || "Video TikTok tidak ditemukan atau bersifat privat.",
        "not_found"
      );
    }

    const d = data.data;
    const formats = [
      d.hdplay && {
        id: "hd",
        label: "Video HD (tanpa watermark)",
        url: toProxyUrl(d.hdplay as string, "tiktok-video-hd.mp4"),
        ext: "mp4",
        isAudio: false,
      },
      d.play && {
        id: "sd",
        label: "Video (tanpa watermark)",
        url: toProxyUrl(d.play as string, "tiktok-video.mp4"),
        ext: "mp4",
        isAudio: false,
      },
      d.music && {
        id: "audio",
        label: "Audio saja (MP3)",
        url: toProxyUrl(d.music as string, "tiktok-audio.mp3"),
        ext: "mp3",
        isAudio: true,
      },
    ].filter(Boolean) as DownloadResult["formats"];

    if (formats.length === 0) {
      throw new DownloaderError(
        "Tidak ada file yang bisa diunduh dari link ini.",
        "not_found"
      );
    }

    return {
      platform,
      sourceUrl: url,
      title: d.title,
      thumbnail: d.cover,
      author: d.author?.nickname,
      formats,
      provider: this.name,
    };
  }
}
