export const siteConfig = {
  name: "ArulKit API",
  url: "https://api.arulkit.my.id",
  docsUrl: "https://app.arulkit.my.id",
  description: "ArulKit REST API for developer integrations.",
};
