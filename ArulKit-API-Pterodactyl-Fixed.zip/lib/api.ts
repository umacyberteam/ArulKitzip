import { NextResponse } from "next/server";

export const API_ORIGIN = "https://api.arulkit.my.id";
export const DOCS_ORIGIN = "https://app.arulkit.my.id";

export function corsHeaders(extra?: HeadersInit) {
  const headers = new Headers(extra);
  headers.set("Access-Control-Allow-Origin", "*");
  headers.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  headers.set("Access-Control-Allow-Headers", "Content-Type, Accept");
  headers.set("Access-Control-Max-Age", "86400");
  return headers;
}

export function apiJson(data: unknown, init?: ResponseInit) {
  return NextResponse.json(data, {
    ...init,
    headers: corsHeaders(init?.headers),
  });
}

export function apiOptions() {
  return new NextResponse(null, { status: 204, headers: corsHeaders() });
}
