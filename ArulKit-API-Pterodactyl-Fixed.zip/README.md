# ArulKit API

REST API project intended for deployment on a Node.js server/Pterodactyl.

## Requirements

- Node.js 20+ recommended
- npm

## Install

```bash
npm install
```

## Build

```bash
npm run build
```

## Start

For Pterodactyl, use the allocated server port:

```bash
npm start -- -H 0.0.0.0 -p $SERVER_PORT
```

If your panel exposes a different environment variable for the allocated port, replace `$SERVER_PORT` accordingly.

## Endpoints

- `GET /api/downloader/proxy`
- `GET /api/anime/search`
- `GET|POST /api/view-source`

## Environment

The project does not require an application secret by default.

## Domain

Put a reverse proxy such as Nginx or Caddy in front of the Node.js process and point:

`api.arulkit.my.id` → your VPS → Pterodactyl allocation.
